package com.example.projectflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
