package com.example.ahya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
